'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation'; // Removido 'redirect'
import { useAuth } from '@/hooks/use-auth';
import { Skeleton } from '@/components/ui/skeleton';

export default function HomePage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  // Redirige al dashboard si el usuario ya está autenticado.
  useEffect(() => {
    if (!loading && user) {
      console.log('User is authenticated, redirecting to dashboard...'); // Debug
      router.push('/dashboard'); // Cambiado de redirect() a router.push()
    }
  }, [user, loading, router]);

  // Muestra un esqueleto de carga mientras se determina el estado de autenticación.
  return (
    <div className="flex h-screen items-center justify-center">
       <div className="flex flex-col items-center gap-4">
        <Skeleton className="h-16 w-16 rounded-full" />
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-4 w-64" />
      </div>
    </div>
  );
}
